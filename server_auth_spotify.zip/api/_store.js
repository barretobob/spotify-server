// /api/_store.js
const store = {};
module.exports = { store };